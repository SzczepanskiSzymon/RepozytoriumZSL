<!DOCTYPE html>
<html lang="pl" dir="ltr">
  <head>
    <meta charset="utf-8">

  </head>
  <body>
    <form action="logowanie.php" method="post">
      Login<input type="text" name="login" value=""><br>
      Hasło<input type="text" name="pass" value=""><br>
      Czy zapamiętać hasło?<input type="checkbox" name="zap" value="ad">
      <input type="submit"  value="submit">
    </form>

  </body>
</html>
<?php
if ($_POST['login']=='Admin' && $_POST['pass']='Admin') {
echo "zalogowano <br>";
}
else {
  echo "niezalogowano <br>";
}
echo $_POST['login'].'<br>';
echo $_POST['pass'].'<br>';

if (isset($_POST['zap'])) {

setcookie('Login', $_POST['login']);
setcookie('pass', $_POST['pass']);


} else {

  setcookie('Login', $_POST['login'], time()-10);
  setcookie('pass', $_POST['pass'], time()-10);
}

 ?>
