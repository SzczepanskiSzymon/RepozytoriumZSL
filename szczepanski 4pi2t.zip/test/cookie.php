<?php
  $value = 'something from somewhere';

  setcookie('testCookie', $value);
  setcookie('test', '', time()-10);
  echo $_COOKIE['testCookie'];
  print_r($_COOKIE);


setcookie('cookie[three]', 'cookiethree');
setcookie('cookie[two]', 'cookietwo');
setcookie('cookie[one]', 'cookieone');

if (isset($_COOKIE['cookie'])) {
  foreach ($_COOKIE['cookie'] as $name => $value) {
    $name = htmlspecialchars($name);
    $value = htmlspecialchars($value);
    echo "$name : $value <br />\n";
  }
}


$tab = array('a' =>'pierwszy' ,'b'=>'drugi' );
setcookie('tab', serialize($tab), time()+3600);
if (isset($_COOKIE['tab'])) {
$tab = unserialize($_COOKIE['tab']);
}
else {
  $tab =  array();
}
var_dump($tab);
 ?>
